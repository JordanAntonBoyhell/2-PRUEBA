import { Config } from './Config.js';

export class InstrumentManager {
    constructor() {
        this.instruments = {
            guitar: {
                rootString: 5,
                originalKey: 'E',
                currentPosition: 0,
                strings: [
                    { name: 'E1', label: 'E (1ª)', notes: ['R', 'X', '2', '3b', '3', '4', 'T', '5', 'X', '6', '7b', 'X'], class: 'string-e' },
                    { name: 'B2', label: 'B (2ª)', notes: ['5', 'X', '6', '7b', 'X', 'R', 'X', '2', '3b', '3', '4', 'T'], class: 'string-b' },
                    { name: 'G3', label: 'G (3ª)', notes: ['3b', '3', '4', 'T', '5', 'X', '6', '7b', 'X', 'R', 'X', '2'], class: 'string-g' },
                    { name: 'D4', label: 'D (4ª)', notes: ['7b', 'X', 'R', 'X', '2', '3b', '3', '4', 'T', '5', 'X', '6'], class: 'string-d' },
                    { name: 'A5', label: 'A (5ª)', notes: ['4', 'T', '5', 'X', '6', '7b', 'X', 'R', 'X', '2', '3b', '3'], class: 'string-a' },
                    { name: 'E6', label: 'E (6ª)', notes: ['R', 'X', '2', '3b', '3', '4', 'T', '5', 'X', '6', '7b', 'X'], class: 'string-e' }
                ],
                numberedPatterns: null
            },
            violin: {
                rootString: 0,
                originalKey: 'G',
                currentPosition: 0,
                strings: [
                    { name: 'E5', label: 'E5 (1ª)', notes: ['6', '7b', 'X', 'R', 'X', '2', '3b', '3', '4', 'T', '5', 'X'], class: 'string-e' },
                    { name: 'A4', label: 'A4 (2ª)', notes: ['2', '3b', '3', '4', 'T', '5', 'X', '6', '7b', 'X', 'R', 'X'], class: 'string-a' },
                    { name: 'D4', label: 'D4 (3ª)', notes: ['5', 'X', '6', '7b', 'X', 'R', 'X', '2', '3b', '3', '4', 'T'], class: 'string-d' },
                    { name: 'G3', label: 'G3 (4ª)', notes: ['R', 'X', '2', '3b', '3', '4', 'T', '5', 'X', '6', '7b', 'X'], class: 'string-g' }
                ],
                numberedPatterns: null
            }
        };

        this.bulletHolePositions = {
            guitar: [
                { stringIndex: 5, degree: 'R', value: '1' },
                { stringIndex: 5, degree: '6', value: '11' },
                { stringIndex: 5, degree: '2', value: '3' },
                { stringIndex: 5, degree: '3b', value: '5' },
                { stringIndex: 5, degree: '4', value: '7' },
                { stringIndex: 5, degree: '5', value: '9' },
                { stringIndex: 5, degree: '7b', value: '13' },
                { stringIndex: 4, degree: '7b', value: '8' },
                { stringIndex: 4, degree: '4', value: '2' },
                { stringIndex: 4, degree: '5', value: '4' },
                { stringIndex: 4, degree: '6', value: '6' },
                { stringIndex: 4, degree: 'R', value: '10' },
                { stringIndex: 4, degree: '3b', value: '14' },
                { stringIndex: 4, degree: '2', value: '12' }
            ],
            violin: [
                { stringIndex: 0, degree: 'X', value: '4' },
                { stringIndex: 0, degree: '2', value: '5' },
                { stringIndex: 0, degree: 'T', value: '8' },
                { stringIndex: 1, degree: '2', value: '2' },
                { stringIndex: 1, degree: '3b', value: '3' },
                { stringIndex: 1, degree: '4', value: '6' }
            ]
        };

        this.grenadePositions = {
            guitar: [
                { stringIndex: 2, degree: '3b', value: 'A' },
                { stringIndex: 2, degree: '4', value: 'B' },
                { stringIndex: 2, degree: '5', value: 'C' },
                { stringIndex: 2, degree: '7b', value: 'D' },
                { stringIndex: 2, degree: 'R', value: 'E' },
                { stringIndex: 2, degree: '2', value: 'F' }
            ],
            violin: []
        };

        this.currentInstrument = 'guitar';
        this.showNotes = false;
    }

    generateFretboardHTML() {
        const instrument = this.instruments[this.currentInstrument];
        const { strings, rootString, originalKey } = instrument;
        let html = '<tr><th class="fret-header">CUERDA</th>';

        for (let i = 0; i < Config.FRET_COUNT; i++) {
            html += `<th class="fret-header">${i}</th>`;
        }
        html += '</tr>';

        if (!instrument.numberedPatterns) {
            instrument.numberedPatterns = this.assignCircleNumbers(strings, this.currentInstrument);
        }

        strings.forEach((string, index) => {
            const rotated = this.rotatePattern(instrument.numberedPatterns[index], instrument.currentPosition);
            const adjusted = [...rotated];
            if (adjusted.length >= 12) {
                adjusted[12] = rotated[0];
            }

            html += `<tr class="string-row ${string.class}">`;
            html += `<td class="string-label">${string.label}</td>`;

            adjusted.slice(0, Config.FRET_COUNT).forEach((note, fret) => {
                html += this.generateFretCell(note, fret, index, originalKey);
            });

            html += '</tr>';
        });

        // Generate new fret footer with custom numbering
        const fretLabels = [0, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 ];
        html += `<tfoot class="fret-footer"><tr><th class="string-label">CUERDA</th>`;
        for (let i = 0; i < Config.FRET_COUNT; i++) {
            html += `<th class="fret-header">${fretLabels[i]}</th>`;
        }
        html += `</tr></tfoot>`;

        const table = document.getElementById('instrument-board');
        if (!table) {
            console.error('Elemento instrument-board no encontrado. Verifica index.html.');
            return html;
        }
        table.innerHTML = html;

        this.highlightCleanColumns(table);
        this.applyBlackText(table);

        return html;
    }

    generateFretCell(note, fret, stringIndex, originalKey) {
        const isNumber = typeof note === 'number';
        const strings = this.instruments[this.currentInstrument].strings;
        let display;

        if (note === 'R') {
            const skullClass = `skull-${strings[stringIndex].name.toLowerCase()}-${fret}`;
            display = `<div class="${skullClass}">💀</div>`;
        } else if (isNumber) {
            display = `${note}`;
        } else if (this.showNotes) {
            const convertedNote = this.degreeToNote(note, Config.CHROMATIC_SCALE.indexOf(originalKey));
            display = convertedNote !== undefined ? convertedNote : note;
        } else {
            display = note;
        }

        const markers = this.getMarkers(stringIndex, note);

        return `
            <td data-note="${isNumber ? 'X' : note}" data-fret="${fret}" class="${note === 'R' ? 'root-cell' : ''}">
                <div class="bomb-sphere ${isNumber ? 'bomb-number' : note === 'R' ? 'root-note' : ''}" data-number="${isNumber ? note : ''}">
                    <div class="main-content">${display}</div>
                    ${markers.bulletHole || ''} <!-- Bullet hole (número) -->
                    ${markers.grenade || ''} <!-- Granada (letra) -->
                </div>
            </td>
        `;
    }

    getMarkers(stringIndex, note) {
        const bulletHolePositions = this.bulletHolePositions[this.currentInstrument];
        const bulletHole = bulletHolePositions.find(pos => pos.stringIndex === stringIndex && pos.degree === note);
        const bulletHoleHTML = bulletHole ? `<div class="bullet-hole">${bulletHole.value}</div>` : '';

        const grenadePositions = this.grenadePositions[this.currentInstrument];
        const grenade = grenadePositions.find(pos => pos.stringIndex === stringIndex && pos.degree === note);
        const grenadeHTML = grenade ? `<div class="grenade">${grenade.value}</div>` : '';

        return {
            bulletHole: bulletHoleHTML,
            grenade: grenadeHTML
        };
    }

    rotatePattern(pattern, shift) {
        const len = pattern.length;
        const effectiveShift = ((shift % len) + len) % len;
        return [...pattern.slice(effectiveShift), ...pattern.slice(0, effectiveShift)];
    }

    degreeToNote(degree, rootIndex) {
        if (degree === 'X' || typeof degree === 'number') return degree;
        const offset = Config.DEGREE_TO_NOTE_OFFSET[degree] || 0;
        return Config.CHROMATIC_SCALE[(rootIndex + offset) % 12];
    }

    highlightCleanColumns(table) {
        const colorRules = {
            guitar: {
                tierra: ['R,5,3b,7b,4,R'],
                fuego: ['2,6,4,R,5,2'],
                naranja: ['3,X,5,2,6,3'],
                aire: ['5,2,7b,4,R,5'],
                agua: ['6,3,R,5,2,6']
            },
            violin: {
                agua: ['6,2,5,R'],
                tierra: ['R,4,7b,3b'],
                fuego: ['2,5,R,4'],
                naranja: ['3,6,2,5'],
                aire: ['5,R,4,7b']
            }
        };
        const rules = colorRules[this.currentInstrument];

        for (let col = 0; col < Config.FRET_COUNT; col++) {
            const cells = table.querySelectorAll(`td[data-fret="${col}"]`);
            const degrees = Array.from(cells, cell => cell.dataset.note).join(',');

            for (const [color, patterns] of Object.entries(rules)) {
                const patternArray = Array.isArray(patterns) ? patterns : [patterns];
                if (patternArray.includes(degrees)) {
                    const className = color === 'naranja2' ? 'clean-naranja2' : `clean-${color}`;
                    cells.forEach(cell => cell.classList.add('clean-column', className));
                    table.querySelectorAll(`th:nth-child(${col + 2})`).forEach(header => {
                        header.classList.add('clean-column', className);
                    });
                    break;
                }
            }
        }
    }

    applyBlackText(table) {
        const targetSequence = this.currentInstrument === 'guitar' ? '5,R,4,7b,2,5' : '5,R,4,7b';
        for (let col = 0; col < Config.FRET_COUNT; col++) {
            const cells = table.querySelectorAll(`td[data-fret="${col}"]`);
            if (Array.from(cells, cell => cell.dataset.note).join(',') === targetSequence) {
                cells.forEach(cell => cell.classList.add('black-text'));
            }
        }
    }

    assignCircleNumbers(strings, instrument) {
        const circleMaps = {
            guitar: [
                [1, 14, 15],
                [2, 7, 9],
                [8, 13, 16],
                [3, 6, 17],
                [5, 10, 12],
                [4, 11, 18]
            ],
            violin: [
                [18, 4, 11],
                [5, 10, 12],
                [17, 3, 6],
                [16, 8, 13]
            ]
        };
        const patterns = strings.map(({ notes }, i) => {
            let circleIndex = 0;
            return notes.map(note => {
                if (note === 'X') {
                    const bombNumber = circleMaps[instrument][i][circleIndex];
                    circleIndex++;
                    return bombNumber !== undefined ? bombNumber : 'X';
                }
                return note;
            });
        });
        return patterns;
    }

    toggleInstrument() {
        this.currentInstrument = this.currentInstrument === 'guitar' ? 'violin' : 'guitar';
        this.instruments[this.currentInstrument].currentPosition = 0;
        this.generateFretboardHTML();
    }

    shiftTone(direction) {
        const instrument = this.instruments[this.currentInstrument];
        instrument.currentPosition = (instrument.currentPosition + direction + 12) % 12;
        this.generateFretboardHTML();
    }

    toggleNotes() {
        this.showNotes = !this.showNotes;
        this.generateFretboardHTML();
    }

    resetPosition() {
        const instrument = this.instruments[this.currentInstrument];
        instrument.currentPosition = 0;
        this.generateFretboardHTML();
    }
}