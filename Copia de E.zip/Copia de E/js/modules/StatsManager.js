import { Config } from './Config.js';

export class StatsManager {
    constructor() {
        if (typeof window.electronStore === 'undefined') {
            console.error('electronStore no está disponible. Asegúrate de que preload.js esté configurado correctamente.');
            this.playerName = 'Recluta123';
            this.totalDme = 0;
        } else {
            this.playerName = window.electronStore.get('playerName') || 'Recluta123';
            this.totalDme = window.electronStore.get(`totalDME_${this.playerName}`) || 0;
        }
        this.stats = {
            game: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 },
            death: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 },
            perro: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 }
        };
        this.loadAllStats();
    }

    loadStats(mode) {
        try {
            if (typeof window.electronStore === 'undefined') {
                return { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 };
            }
            const stats = window.electronStore.get(`${mode}_${this.playerName}`);
            return stats ? JSON.parse(stats) : { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 };
        } catch (error) {
            console.error(`Error al cargar estadísticas para el modo ${mode}:`, error);
            return { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 };
        }
    }

    loadAllStats() {
        try {
            Object.keys(this.stats).forEach(mode => {
                this.stats[mode] = this.loadStats(mode);
            });
            this.calculateTotalDME();
        } catch (error) {
            console.error('Error al cargar todas las estadísticas:', error);
        }
    }

    updateStats(mode, score, rounds = 1) {
        try {
            if (!this.stats[mode]) {
                console.warn(`Modo ${mode} no reconocido. Estadísticas no actualizadas.`);
                return;
            }
            const stats = this.stats[mode];
            stats.totalScore += score;
            stats.maxScore = Math.max(stats.maxScore, score);
            stats.roundsPlayed += rounds;
            stats.dme = Math.floor(stats.totalScore / (Config.DME_POINTS || 167));
            stats.kioken = Math.floor(stats.dme / (Config.KIOKEN_DME || 3));
            this.saveAllStats();
            this.calculateTotalDME();
        } catch (error) {
            console.error(`Error al actualizar estadísticas para el modo ${mode}:`, error);
        }
    }

    calculateTotalDME() {
        try {
            if (typeof window.electronStore === 'undefined') {
                this.totalDme = 0;
                return 0;
            }
            this.totalDme = Object.values(this.stats).reduce((acc, curr) => acc + curr.dme, 0);
            window.electronStore.set(`totalDME_${this.playerName}`, this.totalDme);
            return this.totalDme;
        } catch (error) {
            console.error('Error al calcular total DME:', error);
            return 0;
        }
    }

    saveAllStats() {
        try {
            if (typeof window.electronStore === 'undefined') return;
            Object.entries(this.stats).forEach(([mode, data]) => {
                window.electronStore.set(`${mode}_${this.playerName}`, JSON.stringify(data));
            });
        } catch (error) {
            console.error('Error al guardar estadísticas:', error);
        }
    }

    resetAll() {
        try {
            if (typeof window.electronStore === 'undefined') return;
            this.stats = {
                game: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 },
                death: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 },
                perro: { maxScore: 0, totalScore: 0, dme: 0, kioken: 0, roundsPlayed: 0 }
            };
            this.totalDme = 0;
            window.electronStore.delete(`totalDME_${this.playerName}`);
            Object.keys(this.stats).forEach(mode => {
                window.electronStore.delete(`${mode}_${this.playerName}`);
            });
        } catch (error) {
            console.error('Error al reiniciar estadísticas:', error);
        }
    }

    changePlayerName(newName) {
        try {
            if (typeof window.electronStore === 'undefined') return;
            if (newName && newName.trim() !== '') {
                const oldName = this.playerName;
                this.playerName = newName.trim();
                window.electronStore.set('playerName', this.playerName);
                Object.keys(this.stats).forEach(mode => {
                    const stats = window.electronStore.get(`${mode}_${oldName}`);
                    if (stats) {
                        window.electronStore.set(`${mode}_${this.playerName}`, stats);
                        window.electronStore.delete(`${mode}_${oldName}`);
                    }
                });
                const oldTotalDme = window.electronStore.get(`totalDME_${oldName}`);
                if (oldTotalDme) {
                    window.electronStore.set(`totalDME_${this.playerName}`, oldTotalDme);
                    window.electronStore.delete(`totalDME_${oldName}`);
                }
                this.loadAllStats();
            }
        } catch (error) {
            console.error('Error al cambiar el nombre del jugador:', error);
        }
    }

    getStatsHTML() {
        try {
            const modeNames = {
                game: 'Modo Recluta',
                death: 'Modo Muerte',
                perro: 'Modo Perro'
            };
            let html = '<div class="stats-container">';
            html += `<h2>Jugador: ${this.playerName}</h2>`;
            Object.entries(this.stats).forEach(([mode, data]) => {
                html += `
                    <h2>${modeNames[mode]}</h2>
                    <p>Rondas jugadas: ${data.roundsPlayed}</p>
                    <p>Puntuación máxima: ${data.maxScore.toFixed(1)}</p>
                    <p>Score acumulado: ${data.totalScore.toFixed(1)}</p>
                    <p>DME: ${data.dme}</p>
                    <p>KIOKEN: ${data.kioken}</p>
                `;
            });
            const totalScore = Object.values(this.stats).reduce((acc, curr) => acc + curr.totalScore, 0);
            const totalRounds = Object.values(this.stats).reduce((acc, curr) => acc + curr.roundsPlayed, 0);
            html += `
                <h2>Global</h2>
                <p>Total rondas jugadas: ${totalRounds}</p>
                <p>Score acumulado: ${totalScore.toFixed(1)}</p>
                <p>Total DME: ${this.totalDme}</p>
            `;
            html += '</div>';
            return html;
        } catch (error) {
            console.error('Error al generar HTML de estadísticas:', error);
            return '<p>Error al cargar estadísticas. Por favor, intenta de nuevo.</p>';
        }
    }
}