export const Config = {
    CHROMATIC_SCALE: ['E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B', 'C', 'C#', 'D', 'D#'],
    DEGREE_TO_NOTE_OFFSET: { 'R': 0, '2': 2, '3b': 3, '3': 4, '4': 5, '5': 7, '6': 9, '7b': 10, 'T': 6 },
    FRET_COUNT: 13,
    DME_POINTS: 167,
    KIOKEN_DME: 3,
    INITIAL_LIVES: 3,
    BOMBS_COUNT: 4,
    BRILLO_EFECTO_ACTIVO: true
};