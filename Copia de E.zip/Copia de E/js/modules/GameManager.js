import { Config } from './Config.js';

export class GameManager {
    constructor(statsManager, instrumentManager) {
        this.statsManager = statsManager;
        this.instrumentManager = instrumentManager;
        this.currentInstrument = 'guitar';
        this.gameMode = null;
        this.score = 0;
        this.lives = Config.INITIAL_LIVES;
        this.highlightedBomb = null;
        this.correctAnswer = null;
        this.lastCorrectAnswer = null;
        this.recruitMode = false;
        this.lastToneShift = null;
        this.circleMaps = {
            guitar: [
                [4, 11, 18], [5, 10, 12], [3, 6, 17], 
                [8, 13, 16], [2, 7, 9], [1, 14, 15]
            ],
            violin: [[18, 4, 11], [5, 10, 12], [17, 3, 6], [16, 8, 13]]
        };
    }

    assignCircleNumbers(strings, instrument) {
        const circleMap = this.circleMaps[instrument];
        return strings.map(({ notes }, i) => {
            let circleIndex = 0;
            return notes.map(note => note === 'X' ? circleMap[i][circleIndex++] : note);
        });
    }

    getRandomNumbers(instrument, excludeNumber = null) {
        const allNumbers = this.circleMaps[instrument].flat();
        const filtered = excludeNumber !== null ? allNumbers.filter(n => n !== excludeNumber) : allNumbers;
        const shuffled = filtered.sort(() => 0.5 - Math.random());
        return excludeNumber !== null
            ? [...shuffled.slice(0, 3), excludeNumber].sort(() => 0.5 - Math.random())
            : shuffled.slice(0, 4);
    }

    getRandomToneShift(excludeShift = null) {
        const possibleShifts = Array.from({ length: 12 }, (_, i) => i).filter(s => s !== excludeShift);
        return possibleShifts[Math.floor(Math.random() * possibleShifts.length)];
    }

    startGame() {
        try {
            const bombs = Array.from(document.querySelectorAll('.bomb-sphere.bomb-number[data-number]'));
            if (!bombs.length) {
                console.error('No valid circular bombs found for the game.');
                return;
            }

            let availableBombs = bombs;
            if (this.lastCorrectAnswer !== null) {
                availableBombs = bombs.filter(bomb => parseInt(bomb.dataset.number) !== this.lastCorrectAnswer);
                if (!availableBombs.length) availableBombs = bombs;
            }

            this.highlightedBomb = availableBombs[Math.floor(Math.random() * availableBombs.length)];
            this.correctAnswer = parseInt(this.highlightedBomb.dataset.number);
            this.lastCorrectAnswer = this.correctAnswer;
            this.highlightedBomb.classList.add('highlighted');

            if (Config.BRILLO_EFECTO_ACTIVO) {
                this.applyBrilloEffect();
            }

            const bombNumbers = document.querySelectorAll('.game-bomb .bomb-number');
            if (bombNumbers.length !== Config.BOMBS_COUNT) {
                console.warn(`Expected ${Config.BOMBS_COUNT} bomb numbers, found ${bombNumbers.length}`);
            }
            const numbers = this.getRandomNumbers(this.currentInstrument, this.correctAnswer);
            bombNumbers.forEach((bombNumber, i) => {
                bombNumber.textContent = numbers[i] || '';
            });

            const gameBombs = document.querySelectorAll('.game-bomb');
            gameBombs.forEach((gameBomb) => {
                const newBomb = gameBomb.cloneNode(true);
                gameBomb.replaceWith(newBomb);
            });

            document.querySelectorAll('.game-bomb').forEach((gameBomb) => {
                gameBomb.addEventListener('click', () => this.checkAnswer(gameBomb), { once: true });
            });
        } catch (error) {
            console.error('Error starting game:', error);
        }
    }

    applyBrilloEffect() {
        try {
            const allCells = document.querySelectorAll('.bomb-sphere');
            const brilloActivo = Config.BRILLO_EFECTO_ACTIVO;
            const brilloResaltado = brilloActivo ? 1.6 : 1.0;
            const brilloDisminuido = brilloActivo ? 0.4 : 1.0;

            allCells.forEach(cell => {
                cell.style.filter = cell === this.highlightedBomb 
                    ? `brightness(${brilloResaltado})` 
                    : `brightness(${brilloDisminuido})`;
            });
        } catch (error) {
            console.error('Error applying brillo effect:', error);
        }
    }

    checkAnswer(bomb) {
        try {
            const selectedNumber = parseInt(bomb.querySelector('.bomb-number').textContent);
            const isCorrect = selectedNumber === this.correctAnswer;
            const message = document.getElementById('game-message');

            if (!message) {
                console.error('Game message element not found.');
                return;
            }

            if (isCorrect) {
                const scoreIncrement = this.gameMode === 'game' ? 1 : this.gameMode === 'death' ? 5 : 10;
                this.score += scoreIncrement;
                document.getElementById('score').textContent = `Score: ${this.score}`;
                this.highlightedBomb.classList.add('explode');
                message.textContent = 'GOOD';
                message.className = 'game-message correct show';
                this.statsManager.updateStats(this.gameMode, this.score, this.currentInstrument);
            } else {
                if (this.gameMode === 'death' || this.gameMode === 'perro') {
                    this.lives -= 1;
                    this.updateLivesDisplay();
                    if (this.lives <= 0) {
                        this.score = 0;
                        document.getElementById('score').textContent = `Score: ${this.score}`;
                        message.innerHTML = '<img src="images/DEATH.PNG" alt="DEATH" class="death-image">';
                        message.className = 'game-message incorrect show';
                        setTimeout(() => {
                            this.lives = Config.INITIAL_LIVES;
                            this.updateLivesDisplay();
                            this.endRound();
                        }, 1000);
                        return;
                    }
                }
                message.innerHTML = '<img src="images/DEATH.PNG" alt="DEATH" class="death-image">';
                message.className = 'game-message incorrect show';
            }

            this.highlightedBomb.classList.add('show-number');
            setTimeout(() => this.endRound(), 800);
        } catch (error) {
            console.error('Error checking answer:', error);
        }
    }

    updateLivesDisplay() {
        try {
            const livesContainer = document.getElementById('lives-container');
            if (!livesContainer) {
                console.error('Lives container not found.');
                return;
            }
            livesContainer.innerHTML = Array(this.lives).fill('<span class="life">💀</span>').join('');
        } catch (error) {
            console.error('Error updating lives display:', error);
        }
    }

    endRound() {
        try {
            const message = document.getElementById('game-message');
            if (message) {
                message.classList.remove('correct', 'incorrect', 'show');
                message.innerHTML = ''; // Clear the message content
            }
            if (this.highlightedBomb) {
                this.highlightedBomb.classList.remove('highlighted', 'explode', 'show-number');
                this.highlightedBomb = null;
            }
            document.querySelectorAll('.bomb-sphere').forEach(cell => {
                cell.style.filter = 'brightness(1)';
            });

            if (this.gameMode === 'perro') {
                const newShift = this.getRandomToneShift(this.lastToneShift);
                this.instrumentManager.shiftTone(newShift - this.instrumentManager.instruments[this.currentInstrument].currentPosition);
                this.lastToneShift = newShift;
            }

            this.instrumentManager.generateFretboardHTML();
            if (this.gameMode) {
                this.startGame();
            }
        } catch (error) {
            console.error('Error ending round:', error);
        }
    }

    setGameMode(mode) {
        try {
            this.resetModes();
            this.gameMode = mode;
            this.score = 0;
            this.lives = Config.INITIAL_LIVES;
            this.lastCorrectAnswer = null;
            this.lastToneShift = null;
            this.currentInstrument = this.instrumentManager.currentInstrument;
            
            const scoreEl = document.getElementById('score');
            const bombsEl = document.getElementById('game-bombs');
            const livesEl = document.getElementById('lives-container');

            if (!scoreEl || !bombsEl || !livesEl) {
                console.error('Required game elements not found.');
                return;
            }

            scoreEl.style.display = 'block';
            bombsEl.style.display = 'grid';
            livesEl.style.display = (mode === 'death' || mode === 'perro') ? 'flex' : 'none';
            this.updateLivesDisplay();
            this.startGame();
        } catch (error) {
            console.error('Error setting game mode:', error);
        }
    }

    resetModes() {
        try {
            this.gameMode = null;
            this.score = 0;
            this.lives = Config.INITIAL_LIVES;
            this.lastCorrectAnswer = null;
            this.lastToneShift = null;
            if (this.highlightedBomb) {
                this.highlightedBomb.classList.remove('highlighted', 'explode', 'show-number');
                this.highlightedBomb = null;
            }
            const scoreEl = document.getElementById('score');
            const bombsEl = document.getElementById('game-bombs');
            const livesEl = document.getElementById('lives-container');
            const messageEl = document.getElementById('game-message');

            if (scoreEl) scoreEl.style.display = 'none';
            if (bombsEl) bombsEl.style.display = 'none';
            if (livesEl) livesEl.style.display = 'none';
            if (messageEl) {
                messageEl.classList.remove('correct', 'incorrect', 'show');
                messageEl.innerHTML = ''; // Clear the message content
            }
        } catch (error) {
            console.error('Error resetting modes:', error);
        }
    }
}