import { Config } from './Config.js';

export class UIManager {
    constructor(gameManager, instrumentManager, statsManager) {
        this.gameManager = gameManager;
        this.instrumentManager = instrumentManager;
        this.statsManager = statsManager;
        this.currentMode = null;
    }

    init() {
        try {
            this.setupEventListeners();
            this.initializeBoard();
            this.updateDisplay();
            this.updateTitle();
        } catch (error) {
            console.error('Error initializing UI:', error);
        }
    }

    setupEventListeners() {
        try {
            const modeButtons = [
                { id: 'toggle-game', mode: 'game' },
                { id: 'toggle-death', mode: 'death' },
                { id: 'toggle-perro', mode: 'perro' }
            ];

            modeButtons.forEach(({ id, mode }) => {
                const button = document.getElementById(id);
                if (!button) {
                    console.error(`Button with id ${id} not found`);
                    return;
                }
                
                button.addEventListener('click', () => {
                    if (this.currentMode === mode) {
                        this.deactivateMode(mode, button);
                        return;
                    }
                    
                    if (this.currentMode) {
                        const prevMode = this.currentMode;
                        const prevButtonId = `toggle-${prevMode}`;
                        const prevButton = document.getElementById(prevButtonId);
                        if (prevButton) this.deactivateMode(prevMode, prevButton);
                    }
                    
                    this.activateMode(mode, button);
                });
            });

            const toggleInstrument = document.getElementById('toggle-instrument');
            if (toggleInstrument) {
                toggleInstrument.addEventListener('click', () => {
                    this.instrumentManager.toggleInstrument();
                    this.gameManager.currentInstrument = this.instrumentManager.currentInstrument;
                    toggleInstrument.textContent = this.instrumentManager.currentInstrument === 'guitar' ? '[CAMBIAR A VIOLIN]' : '[CAMBIAR A GUITARRA]';
                    this.initializeBoard();
                    this.updateTitle();
                });
            }

            document.querySelectorAll('[data-tone-shift]').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const direction = parseInt(e.target.dataset.direction);
                    this.instrumentManager.shiftTone(direction);
                    this.initializeBoard();
                    this.updateTitle();
                });
            });

            const toggleNotes = document.getElementById('toggle-notes');
            if (toggleNotes) {
                toggleNotes.addEventListener('click', () => {
                    this.instrumentManager.toggleNotes();
                    toggleNotes.textContent = this.instrumentManager.showNotes ? '[MOSTRAR GRADOS]' : '[MOSTRAR NOTAS]';
                    this.initializeBoard();
                });
            }

            const modalButtons = [
                { id: 'tutorial-button', modal: 'tutorial-modal' },
                { 
                    id: 'global-stats-button', 
                    modal: 'global-stats-modal', 
                    content: () => {
                        const html = this.statsManager.getStatsHTML();
                        console.log('Contenido generado para Estadísticas:', html);
                        return html;
                    }
                },
                { 
                    id: 'player-name-button',
                    modal: 'player-name-modal',
                    init: () => {
                        document.getElementById('player-name-input').value = this.statsManager.playerName;
                    }
                }
            ];

            modalButtons.forEach(({ id, modal, content, init }) => {
                const button = document.getElementById(id);
                if (button) {
                    button.addEventListener('click', () => {
                        console.log(`Botón ${id} clickeado, abriendo modal ${modal}`);
                        if (content) {
                            const contentEl = document.getElementById(`${modal}-content`);
                            if (contentEl) {
                                const htmlContent = content();
                                console.log(`Asignando contenido a ${modal}-content:`, htmlContent);
                                contentEl.innerHTML = htmlContent;
                            } else {
                                console.error(`Elemento ${modal}-content no encontrado en el DOM`);
                            }
                        }
                        if (init) init();
                        this.showModal(modal);
                    });
                } else {
                    console.error(`Botón con id ${id} no encontrado`);
                }
            });

            const saveName = document.getElementById('save-player-name');
            if (saveName) {
                saveName.addEventListener('click', () => {
                    const input = document.getElementById('player-name-input');
                    if (input?.value.trim()) {
                        this.statsManager.playerName = input.value.trim();
                        localStorage.setItem('playerName', this.statsManager.playerName);
                        this.hideModal('player-name-modal');
                        this.updateTitle();
                        this.updateDisplay();
                    }
                });
            }

            const resetStats = document.getElementById('reset-all-stats');
            if (resetStats) {
                resetStats.addEventListener('click', () => {
                    if (confirm('¿Estás seguro de reiniciar todas las estadísticas?')) {
                        this.statsManager.resetAll();
                        this.updateDisplay();
                    }
                });
            }

            const closeApp = document.getElementById('close-app');
            if (closeApp) {
                closeApp.addEventListener('click', () => {
                    if (confirm('¿Estás seguro de cerrar la aplicación?')) {
                        window.close();
                    }
                });
            }

            document.querySelectorAll('.modal-close').forEach(button => {
                button.addEventListener('click', () => {
                    const modal = button.closest('.modal');
                    if (modal) this.hideModal(modal.id);
                });
            });
        } catch (error) {
            console.error('Error setting up event listeners:', error);
        }
    }

    activateMode(mode, button) {
        this.currentMode = mode;
        this.gameManager.setGameMode(mode);
        button.classList.add('active-mode');
        button.textContent = mode === 'game' 
            ? '[SALIR MODO RECLUTA]' 
            : mode === 'death' 
                ? '[SALIR MODO MUERTE]' 
                : '[SALIR MODO PERRO]';
        this.updateBoardStyle();
        this.updateDisplay();
        this.initializeBoard();
    }

    deactivateMode(mode, button) {
        this.currentMode = null;
        this.gameManager.resetModes();
        button.classList.remove('active-mode');
        button.textContent = mode === 'game' 
            ? '[MODO RECLUTA]' 
            : mode === 'death' 
                ? '[MODO MUERTE]' 
                : '[MODO PERRO]';
        this.updateBoardStyle();
        this.updateDisplay();
    }

    initializeBoard() {
        try {
            this.instrumentManager.generateFretboardHTML();
            this.addDynamicStyles();

            document.querySelectorAll('.bomb-sphere').forEach(bomb => {
                bomb.removeEventListener('click', this.handleBombClick.bind(this));
                bomb.addEventListener('click', this.handleBombClick.bind(this));
            });

            const gameBombs = document.getElementById('game-bombs');
            if (!gameBombs) {
                console.error('Game bombs container not found.');
                return;
            }
            gameBombs.innerHTML = Array(Config.BOMBS_COUNT).fill()
                .map(() => `<div class="game-bomb"><span class="bomb-number"></span></div>`).join('');
            gameBombs.style.display = this.gameManager.gameMode ? 'flex' : 'none';

            if (this.gameManager.gameMode) {
                console.log('Starting game from initializeBoard');
                this.gameManager.startGame();
            }
        } catch (error) {
            console.error('Error initializing board:', error);
        }
    }

    handleBombClick(event) {
        try {
            const bomb = event.currentTarget;
            if (!this.currentMode && !bomb.classList.contains('explode')) {
                bomb.classList.add('explode');
                setTimeout(() => bomb.classList.remove('explode'), 500);
            }
        } catch (error) {
            console.error('Error handling bomb click:', error);
        }
    }

    updateTitle() {
        try {
            const { originalKey, currentPosition, rootString } = this.instrumentManager.instruments[this.instrumentManager.currentInstrument];
            const title = document.getElementById('instrument-title');
            if (!title) {
                console.error('Instrument title element not found.');
                return;
            }
            const rootPattern = this.instrumentManager.rotatePattern(
                this.instrumentManager.instruments[this.instrumentManager.currentInstrument].strings[rootString].notes,
                currentPosition
            );
            const rootFret = rootPattern.indexOf('R');
            const originalKeyIndex = Config.CHROMATIC_SCALE.indexOf(originalKey);
            const newKeyIndex = (originalKeyIndex + rootFret) % 12;
            const newKey = Config.CHROMATIC_SCALE[newKeyIndex >= 0 ? newKeyIndex : newKeyIndex + 12];
            const baseTitle = this.instrumentManager.currentInstrument === 'guitar' ? `[GUITARRA] (${newKey})` : `[VIOLIN] (${newKey})`;
            const playerSuffix = this.statsManager.playerName ? ` - Jugador: ${this.statsManager.playerName}` : '';
            title.innerHTML = `${baseTitle}${playerSuffix}`;
        } catch (error) {
            console.error('Error updating title:', error);
        }
    }

    addDynamicStyles() {
        try {
            const style = document.createElement('style');
            style.textContent = `
                .bomb-sphere.highlighted {
                    animation: pulse 1s infinite;
                    box-shadow: 0 0 15px #FF4500;
                }
                .clean-tierra { background: rgba(136, 85, 47, 0.3); }
                .clean-fuego { background: rgba(255, 69, 0, 0.3); }
                .clean-aire { background: rgba(255, 255, 255, 0.3); }
                .clean-agua { background: rgba(30, 144, 255, 0.3); }
                .clean-naranja { background: rgba(255, 165, 0, 0.3); }
                .clean-naranja2 { background: rgba(255, 140, 0, 0.3); }
                .black-text { color: black; }
            `;
            document.head.appendChild(style);
        } catch (error) {
            console.error('Error adding dynamic styles:', error);
        }
    }

    updateDisplay() {
        try {
            const scoreEl = document.getElementById('score');
            const dmeEl = document.getElementById('dme-total');
            const livesEl = document.getElementById('lives-container');

            if (!scoreEl || !dmeEl || !livesEl) {
                console.error('Display elements not found.');
                return;
            }

            scoreEl.textContent = `Score: ${this.gameManager.score}`;
            scoreEl.style.display = this.currentMode ? 'block' : 'none';
            dmeEl.textContent = `DME = ${this.statsManager.totalDme}`;
            livesEl.style.display = (this.currentMode === 'death' || this.currentMode === 'perro') ? 'flex' : 'none';
        } catch (error) {
            console.error('Error updating display:', error);
        }
    }

    updateBoardStyle() {
        try {
            const board = document.getElementById('instrument');
            if (!board) {
                console.error('Instrument board not found.');
                return;
            }
            board.style.borderColor = this.currentMode ? '#464616' : '#464616';
            board.className = `fretboard ${this.instrumentManager.currentInstrument} ${this.currentMode ? 'modo-' + this.currentMode : ''}`;
            console.log(`Applied classes to fretboard: ${board.className}`);
        } catch (error) {
            console.error('Error updating board style:', error);
        }
    }

    showModal(modalId) {
        try {
            const modal = document.getElementById(modalId);
            if (modal) modal.classList.add('show');
        } catch (error) {
            console.error(`Error showing modal ${modalId}:`, error);
        }
    }

    hideModal(modalId) {
        try {
            const modal = document.getElementById(modalId);
            if (modal) modal.classList.remove('show');
        } catch (error) {
            console.error(`Error hiding modal ${modalId}:`, error);
        }
    }
}