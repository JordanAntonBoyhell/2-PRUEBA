import { InstrumentManager } from './modules/InstrumentManager.js';
import { GameManager } from './modules/GameManager.js';
import { UIManager } from './modules/UIManager.js';
import { StatsManager } from './modules/StatsManager.js';

class Application {
    constructor() {
        this.instrumentManager = new InstrumentManager();
        this.statsManager = new StatsManager();
        this.gameManager = new GameManager(this.statsManager, this.instrumentManager);
        this.uiManager = new UIManager(this.gameManager, this.instrumentManager, this.statsManager);
        
        this.initialize();
    }

    initialize() {
        document.addEventListener('DOMContentLoaded', () => {
            this.setupGlobalEventListeners();
            this.uiManager.init();
            this.clearFretboard(); // Limpia el diapasón antes de generarlo
            this.instrumentManager.generateFretboardHTML();
            this.applyInitialConfig();
        });
    }

    setupGlobalEventListeners() {
        document.querySelectorAll('#tutorial-modal .modal-close').forEach(button => {
            button.addEventListener('click', () => {
                this.hideModal('tutorial-modal');
            });
        });
        
        document.getElementById('close-app').addEventListener('click', () => {
            window.close();
        });
    }

    clearFretboard() {
        const fretboard = document.getElementById('instrument-board');
        if (fretboard) {
            fretboard.innerHTML = ''; // Limpia el contenido del diapasón
        }
    }

    applyInitialConfig() {
        document.documentElement.style.setProperty('--main-color', '#688E23');
        document.body.classList.add('loaded');
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
        }
    }
}

new Application();

/* --- BOYHELL: auto-switch after GOOD/DEATH (600ms) + toggle button --- */
(function registerBoyhellAutoSwitch() {
    // Ejecutar tras carga DOM
    document.addEventListener('DOMContentLoaded', () => {
        // bandera global
        window.boyhellAutoSwitch = window.boyhellAutoSwitch || false;

        const boyBtn = document.getElementById('toggle-boyhell');
        const instrumentBtn = document.getElementById('toggle-instrument');
        const messageEl = document.getElementById('game-message');

        if (!boyBtn) {
            console.warn('toggle-boyhell button not found');
            return;
        }
        if (!instrumentBtn) {
            console.warn('toggle-instrument button not found; auto-switch will attempt to click it if present later');
        }
        if (!messageEl) {
            console.warn('game-message element not found; Boyhell observer not attached');
        }

        // Toggle visual / bandera al click del botón Boyhell
        boyBtn.addEventListener('click', () => {
            window.boyhellAutoSwitch = !window.boyhellAutoSwitch;
            boyBtn.classList.toggle('active', window.boyhellAutoSwitch);
            boyBtn.textContent = window.boyhellAutoSwitch ? '[MODO BOYHELL: ON]' : '[MODO BOYHELL]';
            console.log('Boyhell auto-switch:', window.boyhellAutoSwitch);
        });

        // Observer para detectar mensajes GOOD/DEATH en #game-message
        if (messageEl) {
            let lastMessage = '';
            let pendingTimeout = null;

            const scheduleToggle = () => {
                // cancelar si ya pendiente
                if (pendingTimeout) clearTimeout(pendingTimeout);
                // programar 600 ms y disparar la acción exacta que hace el botón manual
                pendingTimeout = setTimeout(() => {
                    pendingTimeout = null;
                    // preferir llamar a la función real si existe
                    if (typeof window.toggleInstrument === 'function') {
                        try { window.toggleInstrument(); return; } catch (e) { /* ignore */ }
                    }
                    // fallback: simular click en el botón manual (mantiene mismo comportamiento)
                    const btn = document.getElementById('toggle-instrument');
                    if (btn) btn.click();
                }, 600);
            };

            const mo = new MutationObserver(() => {
                const text = (messageEl.textContent || '').trim().toUpperCase();
                if (!text || text === lastMessage) return;
                lastMessage = text;
                // comprobar palabras clave GOOD o DEATH (acepta mensajes que contengan)
                if (window.boyhellAutoSwitch && (text.includes('GOOD') || text.includes('DEATH'))) {
                    scheduleToggle();
                }
            });

            mo.observe(messageEl, { childList: true, characterData: true, subtree: true });
            // limpiar on unload
            window.addEventListener('beforeunload', () => {
                mo.disconnect();
            });
        }
    });
})();